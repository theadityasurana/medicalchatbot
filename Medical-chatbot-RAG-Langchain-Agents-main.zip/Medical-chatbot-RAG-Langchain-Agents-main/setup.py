from setuptools import find_packages, setup

setup(
    name='sahu-medical-chatbot',
    version='0.0.1',
    author='Utkarsh Kumar Sahu',
    author_email='utkarsh.bhuiit@gmail.com',
    packages=find_packages()
)
# find_packages() will create folders and then use it as import, find __init__ files     
#  also use "-e ." in requirements.txt to setup 

